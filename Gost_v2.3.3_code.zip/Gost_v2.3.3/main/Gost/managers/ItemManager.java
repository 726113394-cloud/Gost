package io.Sriptirc_wp_1258.gost.managers;

import io.Sriptirc_wp_1258.gost.Gost;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public class ItemManager {
    
    private final Gost plugin;
    private final Map<String, ItemStack> customItems = new HashMap<>();
    
    public ItemManager(Gost plugin) {
        this.plugin = plugin;
        initializeCustomItems();
    }
    
    private void initializeCustomItems() {
        createAdrenaline();
        createFrenzyPotion();
        createIceBall();
        createSoulControl();
        createSecondChance();
        createLevitationPotion();
        // createBlinkPearl(); // 已废弃，使用传送珍珠
        
        // 根据服务器版本决定是否创建冲刺矛
        if (plugin.isSpearRushEnabled()) {
            createSpearRush();
        }
        
        plugin.getLogger().info("ItemManager初始化完成，创建了 " + customItems.size() + " 个自定义物品");
    }
    
    // 创建肾上腺素
    private void createAdrenaline() {
        ItemStack adrenaline = new ItemStack(Material.SPLASH_POTION);
        PotionMeta meta = (PotionMeta) adrenaline.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(ChatColor.GREEN + "肾上腺素");
            meta.setLore(Arrays.asList(
                ChatColor.GRAY + "右键使用获得速度效果",
                ChatColor.GRAY + "持续时间: " + plugin.getConfigManager().getAdrenalineDuration() + "秒",
                ChatColor.GRAY + "速度等级: " + plugin.getConfigManager().getAdrenalineSpeedLevel(),
                "",
                ChatColor.DARK_GRAY + "[消耗品]"
            ));
            
            // 设置药水颜色为绿色
            meta.setColor(Color.fromRGB(0, 255, 0));
            
            adrenaline.setItemMeta(meta);
        }
        
        customItems.put("adrenaline", adrenaline);
    }
    
    // 创建狂暴药水
    private void createFrenzyPotion() {
        ItemStack frenzy = new ItemStack(Material.SPLASH_POTION);
        PotionMeta meta = (PotionMeta) frenzy.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(ChatColor.RED + "狂暴药水");
            meta.setLore(Arrays.asList(
                ChatColor.GRAY + "右键使用获得速度效果",
                ChatColor.GRAY + "持续时间: " + plugin.getConfigManager().getFrenzyDuration() + "秒",
                ChatColor.GRAY + "速度等级: " + plugin.getConfigManager().getFrenzySpeedLevel(),
                "",
                ChatColor.DARK_GRAY + "[消耗品]"
            ));
            
            // 设置药水颜色为红色
            meta.setColor(Color.fromRGB(255, 0, 0));
            
            frenzy.setItemMeta(meta);
        }
        
        customItems.put("frenzy", frenzy);
    }
    
    // 创建凝冰球
    private void createIceBall() {
        ItemStack iceBall = new ItemStack(Material.SNOWBALL);
        ItemMeta meta = iceBall.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(ChatColor.AQUA + "凝冰球");
            meta.setLore(Arrays.asList(
                ChatColor.GRAY + "右键投掷对鬼造成减速效果",
                ChatColor.GRAY + "减速时间: " + plugin.getConfigManager().getIceBallSlowDuration() + "秒",
                ChatColor.GRAY + "减速等级: " + plugin.getConfigManager().getIceBallSlowLevel(),
                "",
                ChatColor.DARK_GRAY + "[消耗品]"
            ));
            
            // 添加发光效果
            meta.addEnchant(ApiCompat.lure(), 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            
            iceBall.setItemMeta(meta);
        }
        
        customItems.put("ice_ball", iceBall);
    }
    
    // 创建控魂术
    private void createSoulControl() {
        ItemStack soulControl = new ItemStack(Material.CLOCK);
        ItemMeta meta = soulControl.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(ChatColor.DARK_PURPLE + "控魂术");
            meta.setLore(Arrays.asList(
                ChatColor.GRAY + "右键使用使所有鬼无法移动",
                ChatColor.GRAY + "冻结时间: " + plugin.getConfigManager().getSoulControlFreezeDuration() + "秒",
                ChatColor.GRAY + "冷却时间: " + plugin.getConfigManager().getSoulControlCooldown() + "秒",
                "",
                ChatColor.DARK_GRAY + "[消耗品]"
            ));
            
            // 添加发光效果
            meta.addEnchant(ApiCompat.lure(), 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            
            soulControl.setItemMeta(meta);
        }
        
        customItems.put("soul_control", soulControl);
    }
    
    // 创建闪现珍珠（已废弃，保留但不使用）
    private void createBlinkPearl() {
        // 这个方法已废弃，保留但不使用
        // 所有传送功能已合并到传送珍珠中
        plugin.getLogger().info("闪现珍珠创建方法已废弃，使用传送珍珠代替");
    }
    
    // 获取物品的方法
    public ItemStack getAdrenaline() {
        return customItems.get("adrenaline").clone();
    }
    
    public ItemStack getFrenzyPotion() {
        return customItems.get("frenzy").clone();
    }
    
    public ItemStack getIceBall() {
        return customItems.get("ice_ball").clone();
    }
    
    public ItemStack getSoulControl() {
        return customItems.get("soul_control").clone();
    }
    
    public ItemStack getBlinkPearl() {
        // 这个方法已废弃，返回空物品
        plugin.getLogger().warning("getBlinkPearl() 方法已废弃，请使用传送珍珠");
        return new ItemStack(Material.AIR);
    }
    
    public ItemStack getSpearRush() {
        ItemStack item = customItems.get("spear_rush");
        return item != null ? item.clone() : null;
    }
    
    public ItemStack getLevitationPotion() {
        return customItems.get("levitation_potion").clone();
    }
    
    // 创建冲刺矛
    public void applyAdrenalineEffect(Player player) {
        int duration = plugin.getConfigManager().getAdrenalineDuration() * 20;
        int level = plugin.getConfigManager().getAdrenalineSpeedLevel() - 1;
        
        player.addPotionEffect(new PotionEffect(
            PotionEffectType.SPEED,
            duration,
            level,
            true,
            true
        ));
        
        player.sendMessage(ChatColor.GREEN + "你使用了肾上腺素！速度提升！");
    }
    
    public void applyFrenzyEffect(Player player) {
        int duration = plugin.getConfigManager().getFrenzyDuration() * 20;
        int level = plugin.getConfigManager().getFrenzySpeedLevel() - 1;
        
        player.addPotionEffect(new PotionEffect(
            PotionEffectType.SPEED,
            duration,
            level,
            true,
            true
        ));
        
        player.sendMessage(ChatColor.RED + "你使用了狂暴药水！速度提升！");
    }
    
    public void applyIceBallEffect(Player target) {
        int duration = plugin.getConfigManager().getIceBallSlowDuration() * 20;
        int level = plugin.getConfigManager().getIceBallSlowLevel() - 1;
        
        plugin.getLogger().info("开始应用凝冰球效果给玩家: " + target.getName() + " (减速等级: " + level + ", 持续时间: " + duration + " ticks)");
        
        boolean success = target.addPotionEffect(new PotionEffect(
            ApiCompat.slowness(),
            duration,
            level,
            true,
            true
        ));
        
        target.sendMessage(ChatColor.AQUA + "你被凝冰球击中了！移动速度降低！");
        plugin.getLogger().info("凝冰球效果应用给玩家: " + target.getName() + " (减速等级: " + level + ", 持续时间: " + duration + " ticks, 成功: " + success + ")");
    }
    
    public void applySoulControlEffect(List<Player> ghostPlayers) {
        int duration = plugin.getConfigManager().getSoulControlFreezeDuration() * 20;
        
        for (Player ghost : ghostPlayers) {
            ghost.addPotionEffect(new PotionEffect(
                ApiCompat.slowness(),
                duration,
                255, // 最大减速效果
                true,
                true
            ));
            
            ghost.sendMessage(ChatColor.DARK_PURPLE + "你被控魂术影响了！无法移动！");
        }
    }
    
    // 应用幽灵感知效果（所有玩家高亮）
    public void applyGhostSenseEffect(List<Player> allPlayers) {
        int duration = plugin.getConfigManager().getGhostSenseDuration() * 20;
        
        // 直接使用GLOWING效果（1.20.x支持）
        for (Player player : allPlayers) {
            player.addPotionEffect(new PotionEffect(
                PotionEffectType.GLOWING,
                duration,
                0,
                true,
                true
            ));
        }
        
        Bukkit.broadcastMessage(ChatColor.YELLOW + "幽灵感知激活！所有玩家高亮显示！");
    }
    
    // 随机分配道具
    public void distributeItems() {
        if (!plugin.getGameManager().isGameRunning()) {
            return;
        }
        
        List<UUID> allPlayers = plugin.getPlayerManager().getAllPlayers();
        List<UUID> humanPlayers = plugin.getPlayerManager().getHumanPlayers();
        List<UUID> ghostPlayers = plugin.getPlayerManager().getGhostPlayers();
        
        // 1. 所有人类获得肾上腺素
        for (UUID playerId : humanPlayers) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null && player.isOnline()) {
                tryGiveItem(player, getAdrenaline(), "肾上腺素");
                player.playSound(player.getLocation(), SoundCompat.itemPickup(), 1.0f, 1.2f);
            }
        }
        
        // 2. 所有鬼获得狂暴药水
        for (UUID playerId : ghostPlayers) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null && player.isOnline()) {
                tryGiveItem(player, getFrenzyPotion(), "狂暴药水");
                player.playSound(player.getLocation(), SoundCompat.itemPickup(), 1.0f, 0.8f);
            }
        }
        
        // 3. 随机6位玩家获得凝冰球
        List<UUID> iceBallRecipients = getRandomPlayers(allPlayers, Math.min(6, allPlayers.size()));
        for (UUID playerId : iceBallRecipients) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null && player.isOnline()) {
                tryGiveItem(player, getIceBall(), "凝冰球");
                player.playSound(player.getLocation(), SoundCompat.itemPickup(), 1.0f, 1.5f);
            }
        }
        
        // 4. 随机3位人类获得控魂术
        if (!humanPlayers.isEmpty()) {
            int count = Math.min(3, humanPlayers.size());
            if (count == 0) count = 1; // 至少1位
            
            List<UUID> soulControlRecipients = getRandomPlayers(humanPlayers, count);
            for (UUID playerId : soulControlRecipients) {
                Player player = Bukkit.getPlayer(playerId);
                if (player != null && player.isOnline()) {
                    tryGiveItem(player, getSoulControl(), "控魂术");
                    player.playSound(player.getLocation(), SoundCompat.itemPickup(), 1.0f, 0.9f);
                }
            }
        }
        
        // 5. 随机6位玩家获得传送珍珠（替换闪现珍珠）
        List<UUID> teleportPearlRecipients = getRandomPlayers(allPlayers, Math.min(6, allPlayers.size()));
        for (UUID playerId : teleportPearlRecipients) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null && player.isOnline()) {
                ItemStack teleportPearl = plugin.getItemSpawnManager().createTeleportPearl();
                tryGiveItem(player, teleportPearl, "传送珍珠");
                player.playSound(player.getLocation(), SoundCompat.itemPickup(), 1.0f, 1.1f);
                plugin.getLogger().info("给予玩家 " + player.getName() + " 传送珍珠");
            }
        }
        
        // 6. 如果冲刺矛可用，随机3位玩家获得冲刺矛
        if (plugin.isSpearRushEnabled()) {
            List<UUID> spearRecipients = getRandomPlayers(allPlayers, Math.min(3, allPlayers.size()));
            for (UUID playerId : spearRecipients) {
                Player player = Bukkit.getPlayer(playerId);
                if (player != null && player.isOnline()) {
                    ItemStack spear = getSpearRush();
                    if (spear != null) {
                        tryGiveItem(player, spear, "冲刺矛");
                        player.playSound(player.getLocation(), SoundCompat.itemPickup(), 1.0f, 1.3f);
                    }
                }
            }
        }
        
        // 7. 随机3位玩家获得漂浮药水
        List<UUID> levitationRecipients = getRandomPlayers(allPlayers, Math.min(3, allPlayers.size()));
        for (UUID playerId : levitationRecipients) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null && player.isOnline()) {
                tryGiveItem(player, getLevitationPotion(), "漂浮药水");
                player.playSound(player.getLocation(), SoundCompat.itemPickup(), 1.0f, 0.7f);
            }
        }
        
        // 8. 救赎者常驻：随机绑定救赎者（每局最多2名）
        if (plugin.getConfigManager().isRedeemerEnabled()) {
            int current = plugin.getDivineGuardianManager().getRedeemerCount();
            int needed = plugin.getConfigManager().getRedeemerMaxCount() - current;
            if (needed > 0 && !humanPlayers.isEmpty()) {
                List<UUID> candidates = new ArrayList<>(humanPlayers);
                candidates.removeIf(id -> plugin.getDivineGuardianManager().isRedeemer(id));
                List<UUID> chosen = getRandomPlayers(candidates, Math.min(needed, candidates.size()));
                for (UUID pid : chosen) {
                    Player p = Bukkit.getPlayer(pid);
                    if (p != null && p.isOnline()) {
                        if (plugin.getDivineGuardianManager().assignRedeemer(p)) {
                            p.playSound(p.getLocation(), SoundCompat.noteBell(), 1.0f, 1.2f);
                        }
                    }
                }
            }
        }
        
        // 发放道具全局音效
        for (UUID playerId : allPlayers) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null && player.isOnline()) {
                player.playSound(player.getLocation(), SoundCompat.notePling(), 0.5f, 1.8f);
            }
        }
        
        Bukkit.broadcastMessage(ChatColor.YELLOW + "道具已发放！");
        plugin.getLogger().info("道具分发完成: 人类=" + humanPlayers.size() + ", 鬼=" + ghostPlayers.size() + 
            ", 凝冰球=" + iceBallRecipients.size() + ", 控魂术=" + (humanPlayers.isEmpty() ? 0 : Math.min(3, humanPlayers.size())) + 
            ", 传送珍珠=" + teleportPearlRecipients.size());
    }
    
    /**
     * 安全发放道具：物品栏满不发放并提示；专属道具已有同款不发放；只放入物品栏（0-8格）
     */
    private void tryGiveItem(Player player, ItemStack item, String itemName) {
        if (player == null || !player.isOnline()) return;
        // 专属道具不允许重复：已有同款不发放（人鬼通用道具不受限）
        if (!isUniversalItem(itemName)) {
            for (ItemStack inv : player.getInventory().getContents()) {
                if (inv != null && inv.hasItemMeta() && inv.getItemMeta().hasDisplayName() &&
                    inv.getItemMeta().getDisplayName().contains(itemName)) {
                    return; // 已有同款，不发放
                }
            }
        }
        // 物品栏（前9格）已满 → 不发放（道具只放入物品栏，不放背包）
        for (int i = 0; i < 9; i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s == null || s.getType() == org.bukkit.Material.AIR) {
                player.getInventory().setItem(i, item);
                player.sendMessage(ChatColor.GREEN + "你获得了" + itemName + "！");
                return;
            }
        }
        player.sendMessage(ChatColor.RED + "物品栏已满！无法获得 " + itemName + "！");
    }
    
    /**
     * 人鬼通用道具（允许重复持有）
     */
    private boolean isUniversalItem(String name) {
        return name.contains("凝冰球") || name.contains("传送珍珠") || 
               name.contains("漂浮药水") || name.contains("臭牛排") || 
               name.contains("冲刺矛");
    }
    
    // 随机选择玩家
    private List<UUID> getRandomPlayers(List<UUID> players, int count) {
        if (players.size() <= count) {
            return new ArrayList<>(players);
        }
        
        List<UUID> shuffled = new ArrayList<>(players);
        Collections.shuffle(shuffled);
        return shuffled.subList(0, count);
    }
    
    // 游戏最后2分钟：随机将一名鬼变回人类
    public void randomGhostToHuman() {
        List<UUID> ghostPlayers = plugin.getPlayerManager().getGhostPlayers();
        if (ghostPlayers.isEmpty()) {
            return;
        }
        
        Collections.shuffle(ghostPlayers);
        UUID selectedGhost = ghostPlayers.get(0);
        
        plugin.getPlayerManager().setPlayerRole(selectedGhost, PlayerManager.PlayerRole.HUMAN);
        
        Player player = Bukkit.getPlayer(selectedGhost);
        if (player != null) {
            player.sendMessage(ChatColor.GREEN + "你在最后时刻被治愈了！变回了人类！");
            Bukkit.broadcastMessage(ChatColor.GREEN + player.getName() + " 在最后时刻被治愈，变回了人类！");
        }
    }
    
    // 创建第二次机会道具
    private void createSecondChance() {
        ItemStack secondChance = new ItemStack(Material.TOTEM_OF_UNDYING);
        ItemMeta meta = secondChance.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&6第二次机会"));
            meta.setLore(Arrays.asList(
                ChatColor.translateAlternateColorCodes('&', "&7可抵挡一次鬼的感染"),
                ChatColor.translateAlternateColorCodes('&', "&6被动触发道具"),
                ChatColor.translateAlternateColorCodes('&', "&a仅限人类使用"),
                ChatColor.translateAlternateColorCodes('&', "&c[唯一道具]"),
                "",
                ChatColor.GRAY + "效果:",
                ChatColor.GRAY + "• 人类: 速度II " + plugin.getConfigManager().getSecondChanceHumanSpeedDuration() + "秒",
                ChatColor.GRAY + "• 人类: 高亮 " + plugin.getConfigManager().getSecondChanceHumanGlowingDuration() + "秒",
                ChatColor.GRAY + "• 鬼: 缓慢I " + plugin.getConfigManager().getSecondChanceGhostSlowDuration() + "秒",
                "",
                ChatColor.GRAY + "冷却时间: " + plugin.getConfigManager().getSecondChanceCooldown() + "秒",
                "",
                ChatColor.DARK_GRAY + "[被动触发]"
            ));
            
            // 添加发光效果
            meta.addEnchant(ApiCompat.lure(), 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            
            secondChance.setItemMeta(meta);
        }
        
        customItems.put("second_chance", secondChance);
        plugin.getLogger().info("已创建第二次机会道具");
    }
    
    // 创建漂浮药水
    private void createLevitationPotion() {
        ItemStack potion = new ItemStack(Material.LINGERING_POTION);
        PotionMeta meta = (PotionMeta) potion.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(ChatColor.LIGHT_PURPLE + "漂浮药水");
            meta.setLore(Arrays.asList(
                ChatColor.GRAY + "右键使用获得漂浮效果",
                ChatColor.GRAY + "持续时间: 4.5秒",
                "",
                ChatColor.DARK_GRAY + "[消耗品]"
            ));
            
            // 设置药水颜色为紫色
            meta.setColor(Color.fromRGB(180, 0, 255));
            
            // 添加发光效果
            meta.addEnchant(ApiCompat.lure(), 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            
            potion.setItemMeta(meta);
        }
        
        customItems.put("levitation_potion", potion);
        plugin.getLogger().info("已创建漂浮药水道具");
    }
    
    // 创建冲刺矛（v2.3.2：低版本矛不存在时使用三叉戟外观）
    private void createSpearRush() {
        ItemStack spear = new ItemStack(resolveSpearMaterial());
        ItemMeta meta = spear.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(ChatColor.GOLD + "冲刺矛");
            meta.setLore(Arrays.asList(
                ChatColor.GRAY + "右键使用向前冲刺5.5米",
                ChatColor.GRAY + "使用后即刻消失",
                "",
                ChatColor.DARK_GRAY + "[一次性道具]"
            ));
            
            // 添加附魔光效
            meta.addEnchant(ApiCompat.lure(), 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            
            spear.setItemMeta(meta);
        }
        
        customItems.put("spear_rush", spear);
        plugin.getLogger().info("已创建冲刺矛道具（外观: " + resolveSpearMaterial().name() + "）");
    }
    
    /**
     * 解析冲刺矛使用的物品材质（v2.3.2）
     * ≥1.21.4 使用 GOLDEN_SPEAR（矛），低版本自动回退为 TRIDENT（三叉戟）
     * 使用字符串匹配避免低版本直接引用枚举常量导致 NoSuchFieldError
     */
    private Material resolveSpearMaterial() {
        try {
            Material spear = Material.matchMaterial("GOLDEN_SPEAR");
            if (spear != null) {
                return spear;
            }
        } catch (Exception ignored) {
            // 低版本枚举不存在，忽略
        }
        return Material.TRIDENT;
    }
    
    // 获取第二次机会道具
    public ItemStack getSecondChance() {
        return customItems.get("second_chance").clone();
    }
    
    // 应用第二次机会效果
    public void applySecondChanceEffect(Player humanPlayer, Player ghostPlayer) {
        plugin.getLogger().info("第二次机会效果触发: 人类=" + humanPlayer.getName() + ", 鬼=" + ghostPlayer.getName());
        
        // 给人类玩家效果
        int humanSpeedDuration = plugin.getConfigManager().getSecondChanceHumanSpeedDuration() * 20;
        int humanSpeedLevel = plugin.getConfigManager().getSecondChanceHumanSpeedLevel() - 1;
        int humanGlowingDuration = plugin.getConfigManager().getSecondChanceHumanGlowingDuration() * 20;
        
        humanPlayer.addPotionEffect(new PotionEffect(
            PotionEffectType.SPEED,
            humanSpeedDuration,
            humanSpeedLevel,
            true,
            true
        ));
        
        humanPlayer.addPotionEffect(new PotionEffect(
            PotionEffectType.GLOWING,
            humanGlowingDuration,
            0,
            true,
            true
        ));
        
        // 给鬼玩家效果
        int ghostSlowDuration = plugin.getConfigManager().getSecondChanceGhostSlowDuration() * 20;
        int ghostSlowLevel = plugin.getConfigManager().getSecondChanceGhostSlowLevel() - 1;
        
        ghostPlayer.addPotionEffect(new PotionEffect(
            ApiCompat.slowness(),
            ghostSlowDuration,
            ghostSlowLevel,
            true,
            true
        ));
        
        // 发送消息
        humanPlayer.sendMessage(plugin.getLanguageManager().getMessage("item.one_chance_triggered"));
        humanPlayer.sendMessage(plugin.getLanguageManager().getMessage("item.random_teleport"));
        ghostPlayer.sendMessage(ChatColor.RED + "目标使用了第二次机会！你被减速了！");
        
        // 广播消息
        Bukkit.broadcastMessage(ChatColor.YELLOW + humanPlayer.getName() + " 使用了第二次机会抵挡了 " + ghostPlayer.getName() + " 的感染！");
        
        plugin.getLogger().info("第二次机会效果应用完成");
    }
    
    // 应用冲刺矛效果
    public void applySpearRushEffect(Player player) {
        // 获取玩家面向方向
        org.bukkit.util.Vector direction = player.getLocation().getDirection();
        
        // 冲刺力度：向前冲刺5米
        double power = plugin.getConfigManager().getSpearRushDistance();
        direction.setY(0); // 取消上升位移
        direction.normalize().multiply(power);
        
        // 应用冲刺速度
        player.setVelocity(direction);
        
        // 音效
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 1.0f, 0.8f);
        
        // 居中字幕提示
        player.sendTitle("§6⚡ 冲刺! ⚡", "§7向前冲刺!", 5, 20, 5);
        
        plugin.getLogger().info("玩家 " + player.getName() + " 使用了冲刺矛");
    }
    
    // 应用漂浮药水效果
    public void applyLevitationEffect(Player player) {
        int duration = (int)(4.5 * 20); // 4.5秒 = 90 ticks
        player.addPotionEffect(new PotionEffect(
            PotionEffectType.LEVITATION,
            duration,
            0,
            true,
            true
        ));
        player.sendMessage(ChatColor.LIGHT_PURPLE + "你使用了漂浮药水！获得漂浮效果！");
    }
}