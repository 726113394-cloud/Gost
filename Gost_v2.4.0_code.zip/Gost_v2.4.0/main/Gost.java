package io.Sriptirc_wp_1258.gost;

import io.Sriptirc_wp_1258.gost.commands.GostCommand;
import io.Sriptirc_wp_1258.gost.commands.GostAdminCommand;
import io.Sriptirc_wp_1258.gost.listeners.*;
import io.Sriptirc_wp_1258.gost.managers.*;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class Gost extends JavaPlugin {
    
    private static Gost instance;
    
    /**
     * bStats 插件 ID。为 0 时不上报任何数据；
     * 在 bstats.org 注册后填入真实 ID 即自动生效。
     */
    private static final int BSTATS_PLUGIN_ID = 0;
    
    private boolean spearRushEnabled = false;
    
    private ConfigManager configManager;
    private GameManager gameManager;
    private PlayerManager playerManager;
    private ItemManager itemManager;
    private TeamManager teamManager;
    private AreaManager areaManager;
    private SelectionManager selectionManager;
    private EconomyManager economyManager;
    private ActionBarManager actionBarManager;
    private LanguageManager languageManager;
    private ItemSpawnManager itemSpawnManager;
    private SecondChanceListener secondChanceListener;
    private DarkEffectManager darkEffectManager;
    private HeartbeatManager heartbeatManager;
    private DivineGuardianManager divineGuardianManager;
    private GhostParticleManager ghostParticleManager;
    private SaturationManager saturationManager;
    
    @Override
    public void onEnable() {
        instance = this;
        
        checkSpearRushSupport();
        
        try {
            configManager = new ConfigManager(this);
            economyManager = new EconomyManager(this);
            areaManager = new AreaManager(this);
            selectionManager = new SelectionManager(this);
            teamManager = new TeamManager(this);
            itemManager = new ItemManager(this);
            playerManager = new PlayerManager(this);
            gameManager = new GameManager(this);
            actionBarManager = new ActionBarManager(this);
            
            try {
                languageManager = new LanguageManager(this);
            } catch (NoClassDefFoundError | Exception e) {
                getLogger().warning("无法初始化 LanguageManager: " + e.getMessage());
                getLogger().warning("语言功能将不可用，但插件会继续运行");
                languageManager = null;
            }
            
            itemSpawnManager = new ItemSpawnManager(this);
            secondChanceListener = new SecondChanceListener(this);
            darkEffectManager = new DarkEffectManager(this);
            heartbeatManager = new HeartbeatManager(this);
            divineGuardianManager = new DivineGuardianManager(this);
            ghostParticleManager = new GhostParticleManager(this);
            saturationManager = new SaturationManager(this);
        } catch (Exception e) {
            getLogger().severe("初始化管理器时发生错误: " + e.getMessage());
            e.printStackTrace();
            gameManager = null;
            return;
        }
        
        try {
            if (languageManager != null) {
                languageManager.reload();
            }
            
            divineGuardianManager.loadConfig();
            ghostParticleManager.loadConfig();
            darkEffectManager.loadConfig();
            
            getLogger().info("==========================================");
            
            getCommand("gost").setExecutor(new GostCommand(this));
            getCommand("gostadmin").setExecutor(new GostAdminCommand(this));
            getCommand("gostadmin").setTabCompleter(new GostAdminCommand(this));
            
            getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
            getServer().getPluginManager().registerEvents(new GameListener(this), this);
            getServer().getPluginManager().registerEvents(new InfectionListener(this), this);
            getServer().getPluginManager().registerEvents(new ItemListener(this), this);
            getServer().getPluginManager().registerEvents(new SelectionListener(this), this);
            getServer().getPluginManager().registerEvents(secondChanceListener, this);
            getServer().getPluginManager().registerEvents(new HolyRedemptionListener(this), this);
            getServer().getPluginManager().registerEvents(new DemonHunterPhaseListener(this), this);
            getServer().getPluginManager().registerEvents(gameManager, this);
            getServer().getPluginManager().registerEvents(saturationManager, this);
            
            getLogger().info("==========================================");
            getLogger().info("服务端兼容: " + io.Sriptirc_wp_1258.gost.managers.ServerCompat.describe());
            getLogger().info("支持: Bukkit/Spigot/Paper/Purpur | Folia(调度兼容)");
            getLogger().info("不适用: Sponge | BungeeCord/Velocity/Waterfall(代理端)");
            getLogger().info("==========================================");
            getLogger().info("作者: 来自太空的小头脑");
            getLogger().info("主页: https://space.bilibili.com/3493116665400113");
            getLogger().info("==========================================");
            
            io.Sriptirc_wp_1258.gost.managers.ServerCompat.runLater(this, () -> {
                configManager.printMigrationReport();
            }, 20L);

            enableMetrics();

            if (getConfig().getBoolean("update-check.enabled", true)) {
                UpdateChecker.checkAsync(this);
            }
        } catch (Exception e) {
            getLogger().severe("注册命令和监听器时发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    @Override
    public void onDisable() {
        if (gameManager != null && gameManager.isGameRunning()) {
            gameManager.forceStopGame();
        }
        if (teamManager != null) {
            teamManager.cleanup();
        }
        if (divineGuardianManager != null) {
            divineGuardianManager.cleanup();
        }
        if (ghostParticleManager != null) {
            ghostParticleManager.cleanup();
        }
        if (saturationManager != null) {
            saturationManager.shutdown();
        }
        getLogger().info("Gost 插件已禁用");
    }
    
    /**
     * bStats 匿名统计（可选）。
     *
     * <p>ID 为 0 时不上报任何数据 —— 在 <a href="https://bstats.org">bstats.org</a>
     * 注册插件后把真实 ID 填到 {@link #BSTATS_PLUGIN_ID} 即可生效，无需改动其他代码。</p>
     *
     * <p>服务器主可通过 bStats 自身的 {@code plugins/bStats/config.yml} 全局关闭，
     * 因此本插件不再额外提供开关。</p>
     */
    private void enableMetrics() {
        if (BSTATS_PLUGIN_ID <= 0) {
            getLogger().info("bStats 统计未启用（插件 ID 未配置）");
            return;
        }
        try {
            new org.bstats.bukkit.Metrics(this, BSTATS_PLUGIN_ID);
            getLogger().info("bStats 统计已启用（ID " + BSTATS_PLUGIN_ID + "）");
        } catch (Throwable t) {
            getLogger().warning("bStats 初始化失败: " + t.getMessage());
        }
    }

    public static Gost getInstance() {
        return instance;
    }
    
    public ConfigManager getConfigManager() { return configManager; }
    public GameManager getGameManager() { return gameManager; }
    public PlayerManager getPlayerManager() { return playerManager; }
    public ItemManager getItemManager() { return itemManager; }
    public TeamManager getTeamManager() { return teamManager; }
    public AreaManager getAreaManager() { return areaManager; }
    public SelectionManager getSelectionManager() { return selectionManager; }
    public EconomyManager getEconomyManager() { return economyManager; }
    public ActionBarManager getActionBarManager() { return actionBarManager; }
    public LanguageManager getLanguageManager() {
        if (languageManager == null) {
            languageManager = new LanguageManager(this);
        }
        return languageManager;
    }
    public ItemSpawnManager getItemSpawnManager() { return itemSpawnManager; }
    public SecondChanceListener getSecondChanceListener() { return secondChanceListener; }
    public DarkEffectManager getDarkEffectManager() { return darkEffectManager; }
    public HeartbeatManager getHeartbeatManager() { return heartbeatManager; }
    public DivineGuardianManager getDivineGuardianManager() { return divineGuardianManager; }
    public GhostParticleManager getGhostParticleManager() { return ghostParticleManager; }
    public SaturationManager getSaturationManager() { return saturationManager; }
    
    public boolean isSpearRushEnabled() {
        return spearRushEnabled;
    }
    
    private void checkSpearRushSupport() {
        String version = Bukkit.getBukkitVersion();
        getLogger().info("检测到服务器版本: " + version);
        try {
            String verNum = version.split("-")[0];
            String[] parts = verNum.split("\\.");
            int major = Integer.parseInt(parts[0]);
            int minor = Integer.parseInt(parts[1]);
            int patch = (parts.length > 2) ? Integer.parseInt(parts[2]) : 0;
            if (major > 1 || (major == 1 && minor > 21) || (major == 1 && minor == 21 && patch >= 4)) {
                // ≥1.21.4：矛（GOLDEN_SPEAR）存在，使用矛外观
                spearRushEnabled = true;
                getLogger().info("✓ 冲刺矛功能已启用（服务器版本 ≥ 1.21.4，使用长矛外观）");
            } else {
                // <1.21.4：矛不存在，使用三叉戟外观（TRIDENT），功能不变
                spearRushEnabled = true;
                getLogger().info("✓ 冲刺矛功能已启用（服务器版本 < 1.21.4，使用三叉戟外观）");
            }
        } catch (Exception e) {
            spearRushEnabled = false;
            getLogger().warning("无法解析服务器版本，冲刺矛功能已禁用: " + e.getMessage());
        }
    }
}
